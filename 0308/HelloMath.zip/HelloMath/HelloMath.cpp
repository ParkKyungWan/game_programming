﻿#include <iostream>

int main()
{
	double pi = 3.1415926535;
	double x, y;
	x = pi / 4;
	y = sin(x);
	printf(" sin(45º) = %f \n", y);
}
